/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "minheap.h"

//Write your code below this line

MinHeap::MinHeap(){
    size=0;
    root=nullptr;
}

HeapNode* findParent(HeapNode* node, HeapNode* root) {
    if (!node || node == root) {
        return nullptr; // Node is null or the root has no parent
    }

    int location = findNodeLocation(root, node);
    int parentLocation = (location - 1) / 2;
    if (parentLocation >= 0) {
        return getNodeAt(parentLocation);
    }

    return nullptr; // Parent not found
}

int findNodeLocation(HeapNode* node, int value, int index) {
    if (!node) {
        return -1; // Node not found
    }

    if (node->val == value) {
        return index; // Node found at this index
    }

    // Search in the left subtree (if it exists)
    int leftIndex = findNodeLocation(node->left, value, 2 * index + 1);
    if (leftIndex != -1) {
        return leftIndex; // Node found in the left subtree
    }

    // Search in the right subtree (if it exists)
    int rightIndex = findNodeLocation(node->right, value, 2 * index + 2);
    return rightIndex; // Node found in the right subtree (or not found)
}

int findNodeLocation(HeapNode* node, HeapNode* targetNode) {
    if (!node || !targetNode) {
        return -1; // Node not found
    }
    return findNodeLocation(root, targetNode->val, 0);
}

void swap(HeapNode* node1, HeapNode* node2) {
    if (!node1 || !node2) {
        return;
    }

    int temp=node1->val;
    node1->val=node2->val;
    node2->val=temp;
}

void upHeap(HeapNode* node) {
    if (!node || node == root) {
        return; // Nothing to do if the node is null or it's already the root.
    }

    HeapNode* parent = findParent(node,root);

    if (parent && node->val < parent->val) {
        // Swap the node and its parent if the node is smaller.
        int temp=node->val;
        node->val=parent->val;
        parent->val=temp;
        upHeap(parent); // Continue up-heap operation recursively.
    }
}

void MinHeap::push_heap(int num){
    HeapNode* newNode = new HeapNode(num);

    // If the heap is empty, set the new node as the root
    if (size == 0) {
        root = newNode;
    } else {
        // Find the parent of the new node
        int parentIdx = (size - 1) / 2;
        HeapNode* parent = getNodeAt(parentIdx);

        // Insert the new node as the last leaf
        if (parent->left == nullptr) {
            parent->left = newNode;
        } else {
            parent->right = newNode;
        }

        // Perform the up-heap operation to maintain the heap property
        upHeap(newNode);
    }
    size++;
}

int MinHeap::get_min(){
    if (size == 0) {
        // Handle the case when the heap is empty
        return -1; // Replace -1 with appropriate handling or error reporting
    }

    return root->val;
}

void downHeap(HeapNode* node) {
    if (!node) {
        return; // Nothing to do if the node is null.
    }

    HeapNode* leftChild = node->left;
    HeapNode* rightChild = node->right;
    HeapNode* smallest = node;

    if (leftChild && leftChild->val < smallest->val) {
        smallest = leftChild;
    }
    if (rightChild && rightChild->val < smallest->val) {
        smallest = rightChild;
    }

    if (smallest != node) {
        // Swap the node and its smallest child if the child is smaller.
        int temp=node->val;
        node->val=smallest->val;
        smallest->val=temp;
        downHeap(smallest); // Continue down-heap operation recursively.
    }
}

HeapNode* getNodeAt(int location) {
    // Check if the location is within valid bounds
    if (location < 0 || location >= size) {
        return nullptr;
    }

    return getNodeAt(root, location);
}

HeapNode* getNodeAt(HeapNode* current, int location) {
    if (!current || location < 0) {
        return nullptr;
    }

    if (location == 0) {
        return current;
    }

    // Calculate the location for the left and right children
    int leftLoc = 2 * location + 1;
    int rightLoc = 2 * location + 2;

    if (leftLoc < size) {
        HeapNode* leftChild = getNodeAt(current->left, leftLoc);
        if (leftChild) {
            return leftChild;
        }
    }

    if (rightLoc < size) {
        HeapNode* rightChild = getNodeAt(current->right, rightLoc);
        if (rightChild) {
            return rightChild;
        }
    }

    return nullptr;
}

HeapNode* getParentOf(HeapNode* node) {
    if (!node || node == root) {
        return nullptr; // Node is null or the root has no parent
    }

    int location = 0; // Initialize the location to find the parent

    // Find the location of the given node
    for (int i = 0; i < size; i++) {
        if (getNodeAt(i) == node) {
            location = i;
            break;
        }
    }

    // Calculate the location of the parent node
    int parentLocation = (location - 1) / 2;

    if (parentLocation >= 0 && parentLocation < size) {
        return getNodeAt(parentLocation);
    }

    return nullptr; // Parent not found
}

void MinHeap::pop(){
    if (size == 0) {
        // Handle the case when the heap is empty
        return; // Replace with appropriate handling
    }

    // Replace the root node with the last leaf
    HeapNode* lastNode = getNodeAt(size - 1);
    root->val = lastNode->val;

    // Remove the last leaf node
    if (lastNode == root) {
        root = nullptr;
    } else {
        HeapNode* parent = getParentOf(lastNode);
        if (parent->left == lastNode) {
            parent->left = nullptr;
        } else {
            parent->right = nullptr;
        }

        // Perform the down-heap operation to maintain the heap property
        downHeap(root);
    }

    // Deallocate the last node
    delete lastNode;

    size--;
}

void deleteNode(HeapNode* node) {
    if (!node) {
        return; // Nothing to do if the node is null.
    }

    // Recursively delete left and right subtrees
    deleteNode(node->left);
    deleteNode(node->right);

    // Delete the current node
    delete node;
}

MinHeap::~MinHeap(){
    if (root != nullptr) {
        deleteNode(root);
    }
}

