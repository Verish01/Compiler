/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symnode.h"

//Write your code below this line

SymNode::SymNode(){
    key="";
    height=0;
    address=-1;
    par=nullptr;
    left=nullptr;
    right=nullptr;
}

SymNode::SymNode(string k){
    key=k;
    height=0;
    address=-1;
    par=nullptr;
    left=nullptr;
    right=nullptr;
}

SymNode* SymNode::RightRightRotation(){
    SymNode* node1 = this->right;
    SymNode* node2 = node1->left;
    node1->left=this;
    this->right=node2;
    
    int leftHeight;
    if (left != nullptr) {
        leftHeight = left->height;
    } else {
        leftHeight = -1;
    }

    int rightHeight;
    if (right != nullptr) {
        rightHeight = right->height;
    } else {
        rightHeight = -1;
    }

    node1->height=1 + std::max(leftHeight, rightHeight); 
    return node1;
}

SymNode* SymNode::LeftLeftRotation(){
    SymNode* node1 = this->left;
    SymNode* node2 = node1->right;
    node1->right=this;
    this->left=node2;
    
    // Update heights for the current node and the new root.
    int leftHeight;
    if (left != nullptr) {
        leftHeight = left->height;
    } else {
        leftHeight = -1;
    }

    int rightHeight;
    if (right != nullptr) {
        rightHeight = right->height;
    } else {
        rightHeight = -1;
    }

    node1->height=1 + std::max(leftHeight, rightHeight); 
    return node1;
}

SymNode* SymNode::LeftRightRotation(){
    SymNode* node=this->left;
    SymNode* left=node->RightRightRotation();
    this->left=left;
    SymNode* newroot=this->LeftLeftRotation();
    return newroot;
}

SymNode* SymNode::RightLeftRotation(){
    SymNode* node=this->right;
    SymNode* right=node->LeftLeftRotation();
    this->right=right;
    SymNode* newroot=this->RightRightRotation();
    return newroot;
}

SymNode::~SymNode(){
    delete left;
    delete right;
}