/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "parser.h"

//Write your code below this line

Parser::Parser(){
    last_deleted=-1;
    symtable=new SymbolTable();
    vector<ExprTreeNode*> expr_trees;
}

bool isoperator(string &a){
    if ((a=="+")||(a=="-")||(a=="*")||(a=="/")){
        return true;
    }
    return false;
}

ExprTreeNode* make_op_node(string &a, ExprTreeNode* l, ExprTreeNode* r){
    ExprTreeNode* node= new ExprTreeNode();
    if (a=="+"){
        node->type="ADD";
    }
    else if (a=="-"){
        node->type="SUB";
    }
    else if (a=="*"){
        node->type="MUL";
    }
    else if (a=="/"){
        node->type="DIV";
    }
    node->left=l;
    node->right=r;
    return node;
}

void Parser::parse(vector<string> expression){
    vector<string> a;
    vector<ExprTreeNode*> b;
    if(expression[0]=="del"){
        if (2 < expression.size() && expression[2] == "VAR") {
        ExprTreeNode* deleteNode = new ExprTreeNode();
        
        ExprTreeNode* delNode = new ExprTreeNode();
        delNode->type="DEL";
        deleteNode->left = delNode;
        
        ExprTreeNode* varNode = new ExprTreeNode();
        varNode->type="VAR";
        varNode->id = expression[2];
        deleteNode->right = varNode;
        expr_trees.push_back(deleteNode);
        // SymbolTable* symtable;
        
        if (symtable->search(expression[2])==1){
            symtable->remove(expression[2]);
        }
        
        }
    }
    else if (expression[0]=="ret"){
        for (int i=2; i<expression.size(); i++){
            if (expression[i]=="("){
                continue;
            }
            else if(isoperator(expression[i])){
                a.push_back(expression[i]);
                continue;
            }
            else if(expression[i]==")"){
                string op=a[a.size()-1];
                a.pop_back();
                ExprTreeNode* rightnode=b[b.size()-1];
                b.pop_back();
                ExprTreeNode* leftnode=b[b.size()-1];
                b.pop_back();
                ExprTreeNode* node=make_op_node(op,leftnode,rightnode);
                b.push_back(node);
                continue;
            }
            else{
                ExprTreeNode* temp=new ExprTreeNode();
                temp->type="VAL";
                temp->num=stoi(expression[i]);
                // SymbolTable* symtable;
                symtable->insert(expression[i]);
                b.push_back(temp);
            }
        }
        ExprTreeNode* rightnode=b[0];
        ExprTreeNode* enode=new ExprTreeNode();
        enode->type="equal";
        ExprTreeNode* node=new ExprTreeNode();
        node->type="RET";
        enode->left=node;
        enode->right=rightnode;
    }
    else{
        for (int i=2; i<expression.size(); i++){
            if (expression[i]=="("){
                continue;
            }
            else if(isoperator(expression[i])){
                a.push_back(expression[i]);
                continue;
            }
            else if(expression[i]==")"){
                string op=a[a.size()-1];
                a.pop_back();
                ExprTreeNode* rightnode=b[b.size()-1];
                b.pop_back();
                ExprTreeNode* leftnode=b[b.size()-1];
                b.pop_back();
                ExprTreeNode* node=make_op_node(op,leftnode,rightnode);
                b.push_back(node);
                continue;
            }
            else{
                ExprTreeNode* temp=new ExprTreeNode();
                temp->type="VAL";
                temp->num=stoi(expression[i]);
                b.push_back(temp);
            }
        }
        ExprTreeNode* rightnode=b[0];
        ExprTreeNode* node=new ExprTreeNode();
        node->type="VAR";
        node->id=expression[0];
        ExprTreeNode* enode=new ExprTreeNode();
        enode->type="equal";
        enode->left=node;
        enode->right=rightnode;
        // SymbolTable* symtable;
        symtable->insert(expression[0]);
        expr_trees.push_back(enode);
    }
}
void deleteSubtree(ExprTreeNode* node) {
    if (node) {
        // Recursively delete the left and right subtrees
        deleteSubtree(node->left);
        deleteSubtree(node->right);

        // Delete the current node
        delete node;
    }
}

Parser::~Parser(){
    for (ExprTreeNode* node : expr_trees) {
        deleteSubtree(node);
    }
    expr_trees.clear();
}