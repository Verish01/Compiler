/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "eppcompiler.h"

//Write your code below this line

EPPCompiler::EPPCompiler(){
    memory_size = 0;
    output_file = "";
}

EPPCompiler::EPPCompiler(string out_file,int mem_limit){
    memory_size = mem_limit;
    output_file = out_file;
    mem_loc.reserve(mem_limit);
    for (int i = 0; i < mem_limit; ++i) {
        mem_loc.push_back(i);
    }
}

vector<string> generateTargCommandsFromExpression(ExprTreeNode* node, MinHeap& least_mem_loc) {
    vector<string> commands;
    
    if (node == nullptr) {
        return commands;
    }
    
    // Check the type of the current node
    if (node->type == "VAR") {
        // Variable node, get the variable name and memory location
        string variableName = node->id;
        int memoryLocation = targ.symtable.get_memory_location(variableName);
        
        // Generate the Targ command for loading the variable's value
        string loadCommand = "LOAD " + to_string(memoryLocation);
        commands.push_back(loadCommand);
    } else if (node->type == "VAL") {
        // Value node, directly push the value onto the stack
        string valueCommand = "PUSH " + to_string(node->num);
        commands.push_back(valueCommand);
    } else {
        // Operator node, recursively process left and right subtrees
        vector<string> leftCommands = generateTargCommandsFromExpression(node->left, least_mem_loc);
        vector<string> rightCommands = generateTargCommandsFromExpression(node->right, least_mem_loc);
        
        // Combine commands from left and right subtrees with the current operator
        commands.insert(commands.end(), leftCommands.begin(), leftCommands.end());
        commands.insert(commands.end(), rightCommands.begin(), rightCommands.end());
        commands.push_back(node->type);  // Add the current operator
        
        if (node->type == ":=") {
            // Handle variable assignment: Store the result in the variable's memory location
            string variableName = node->left->id;
            int memoryLocation = targ.symtable.get_memory_location(variableName);
            
            // Generate the Targ command for storing the result
            string storeCommand = "STORE " + to_string(memoryLocation);
            commands.push_back(storeCommand);
        } else if (node->type == "DEL") {
            // Handle variable deletion: Release the memory location and push it into least_mem_loc
            string variableName = node->right->id;
            int memoryLocation = targ.symtable.get_memory_location(variableName);
            
            // Generate the Targ command for releasing memory
            least_mem_loc.push_heap(memoryLocation);
        }
    }
    
    return commands;
}

void EPPCompiler::compile(vector<vector<string>> code){
    for (vector<string> expression : code) {
        targ.parse(expression);

        // Handle symbol table operations and memory assignments based on the parsed expression
        // Use least_mem_loc to get the least memory location and assign it to the variable

        // Check if the expression is an assignment (variable declaration)
        if (expression.size() >= 3 && expression[1] == ":=") {
            string variableName = expression[0];
            
            // Check if the variable already exists in the symbol table
            int existingIndex = targ.symtable.search(variableName);
            if (existingIndex != -1) {
                // Variable already exists; reassign it to a new memory location
                int newMemoryLocation = least_mem_loc.get_min();
                least_mem_loc.pop();
                targ.symtable.assign_address(variableName, newMemoryLocation);
            } else {
                // Variable doesn't exist; assign a new memory location
                int newMemoryLocation = least_mem_loc.get_min();
                least_mem_loc.pop();
                targ.symtable.insert(variableName, newMemoryLocation);
            }
        } else if (expression.size() >= 2 && expression[0] == "del") {
            // Check if the expression is a delete statement
            string variableName = expression[2];
            
            // Check if the variable exists in the symbol table
            int existingIndex = targ.symtable.search(variableName);
            if (existingIndex != -1) {
                // Variable exists; free up its memory location
                int memoryLocation = targ.symtable.get_memory_location(variableName);
                least_mem_loc.push_heap(memoryLocation);
                targ.symtable.remove(variableName);
            } else {
                // Variable doesn't exist; handle this case as needed
            }
        }
    }
}

vector<string> EPPCompiler::generate_targ_commands(){
    vector<string> commands;
    
    for (ExprTreeNode* root : targ.expr_trees) {
        vector<string> targCommands = generateTargCommandsFromExpression(root, least_mem_loc);
        commands.insert(commands.end(), targCommands.begin(), targCommands.end());
    }
    
    return commands;
}

void EPPCompiler::write_to_file(vector<string> commands){
    ofstream output(output_file);
    if (output.is open()) {
        for (string command : commands) {
            output << command << endl;
        }
        output.close();
    } else {
        // Handle error: Unable to open the output file
    }
}

EPPCompiler::~EPPCompiler(){
    least_mem_loc.clear();
}
