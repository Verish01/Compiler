/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"

//Write your code below this line

SymbolTable::SymbolTable(){
    size=0;
    root=nullptr;
}

int getHeight(SymNode* node) {
    if (node == nullptr)
        return 0;
    return max(getHeight(node->left),getHeight(node->right))+1;
}

int getBalanceFactor(SymNode* node) {
    if (node == nullptr)
        return 0;
    return (getHeight(node->left) - getHeight(node->right));
}

SymNode* getMinValueNode(SymNode* node) {
    SymNode* current = node;
    while (current->left != nullptr) {
        current = current->left;
    }
    return current;
}

SymNode* insertRecursive(SymNode* node, std::string k) {
    if (node == nullptr) {
        return new SymNode(k);
    }

    if (k < node->key) {
        node->left = insertRecursive(node->left, k);
    } else if (k > node->key) {
        node->right = insertRecursive(node->right, k);
    }

    node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));
    int balance = getBalanceFactor(node);

    if (balance > 1 && k < node->left->key) {
        return node->LeftLeftRotation();
    }

    if (balance < -1 && k > node->right->key) {
        return node->RightRightRotation();
    }

    if (balance > 1 && k > node->left->key) {
        return node->LeftRightRotation();
    }

    if (balance < -1 && k < node->right->key) {
        return node->RightLeftRotation();
    }

    return node;
}

void SymbolTable::insert(string k){
    root = insertRecursive(root, k);
    size++;
    return;
}

SymNode* removeRecursive(SymNode* node, std::string k) {
    // Base case: If the node is null, return null.
    if (node == nullptr) {
        return node;
    }

    if (k < node->key) {
        node->left = removeRecursive(node->left, k);
    }

    else if (k > node->key) {
        node->right = removeRecursive(node->right, k);
    }
    else {
        if (node->left == nullptr || node->right == nullptr) {
            SymNode* temp;
            if (node->left != nullptr) {
                temp = node->left;
                delete temp;
                return node;
            } else {
                temp = node->right;
                delete temp;
                return node;
            }

            // No child case
            if (temp == nullptr) {
                temp = node;
                node = nullptr;
            } else {
                *node = *temp; 
            }
            delete temp;
        } else {
            SymNode* temp = getMinValueNode(node->right);
            node->key = temp->key;
            node->right = removeRecursive(node->right, temp->key);
        }
    }

    if (node == nullptr) {
        return node;
    }
    node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));
    int balance = getBalanceFactor(node);

    // Left Left Case
    if (balance > 1 && getBalanceFactor(node->left) >= 0) {
        return node->LeftLeftRotation();
    }

    // Right Right Case
    if (balance < -1 && getBalanceFactor(node->right) <= 0) {
        return node->RightRightRotation();
    }

    // Left Right Case
    if (balance > 1 && getBalanceFactor(node->left) < 0) {
        return node->LeftRightRotation();
    }

    // Right Left Case
    if (balance < -1 && getBalanceFactor(node->right) > 0) {
        return node->RightLeftRotation();
    }

    return node;
}

void SymbolTable::remove(string k){
    root = removeRecursive(root, k);
    size--;
    return;
}

SymNode* searchRec(SymNode* node, string k) {
    SymNode* x;
    if (node == nullptr) {
        return nullptr; // Symbol not found
    }
    if (k < node->key) {
        return searchRec(node->left, k);
    } else if (k > node->key) {
        return searchRec(node->right, k);
    } else {
        return node; // Symbol found
    }
}

int SymbolTable::search(string k){
    if (searchRec(root,k)){
        return 1;
    }
    return -2;
}

void SymbolTable::assign_address(string k,int idx){
    if (search(k)==1){
        searchRec(root,k)->address=idx;
    }
    return;
}

int SymbolTable::get_size(){
    return size;
}

SymNode* SymbolTable::get_root(){
    return root;
}

void destroyTree(SymNode* node) {
    if (node == nullptr) {
        return;
    }

    destroyTree(node->left);
    destroyTree(node->right);

    delete node;
}

SymbolTable::~SymbolTable(){
    destroyTree(root);
}